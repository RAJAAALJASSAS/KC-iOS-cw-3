import UIKit

var name = "Rajaa"
var hobby = "Photography"
var favouriteNumber = 1

let BirthOfDate = 2008

print("hello my name is \(name) I love \(hobby) and my favouriteNumber is\(favouriteNumber) \n and i was born at \(BirthOfDate)")

